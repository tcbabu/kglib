#include <stdio.h>
void *Rundemo(void *);
int main(void) {
// kgStartX(NULL) //can be used;
  Rundemo(NULL);
//  kgCloseX(); //canbe used
  return 1;
}
