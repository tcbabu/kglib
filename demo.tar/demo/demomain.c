#include <stdio.h>
void *Rundemo(void *,void *);
int main(void) {
// kgStartX(NULL) //can be used;
  Rundemo(NULL,NULL);
//  kgCloseX(); //canbe used
  return 1;
}
