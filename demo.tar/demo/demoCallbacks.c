#include <kulina.h>
#include "images.c"
char myFolder[500]="/usr/share/icons";
//     strcpy(myFolder,"/usr/share/icons/CratOS_lion-icons/apps/scalable");

#define ScrollWrite(txt) {\
  DIS *s;\
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");\
  kgWrite(s,txt);\
}
#define InfoWrite(txt) {\
  DII *s;\
  int id;\
  s= (DII *)kgGetNamedWidget(Tmp,"InfoBox");\
  kgWrite(s,txt); \
}
#define MsgWrite(txt) {\
  DIM *s;\
  int id;\
  s= (DIM *)kgGetNamedWidget(Tmp,"MsgBox");\
  kgWrite(s,txt);\
  kgUpdateOn(Tmp);\
}
#define DrawBox(txt) {\
  DIP *s;\
  int id;\
  s= (DIP *)kgGetNamedWidget(Tmp,"PicBox");\
  s->xpm = kgChangeSizeImage(kgGetImage(buf),(s->x2-s->x1),(s->y2-s->y1));\
  kgUpdateWidget(s);\
  kgUpdateOn(Tmp);\
}
//  kgUpdateWidget(s);
static char buf[500];
int  demosplbutton1callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIL *B; 
  int n,ret=1; 
  D = (DIALOG *)Tmp;
  B = (DIL *) kgGetWidget(Tmp,i);
  n = B->nx;
  InfoWrite("You Pressed the special button");
  switch(butno) {
    case 1: 
	    ret = kgCheckMenu(Tmp,300,200,"Really Quit",0);
      break;
  }
  return ret;
}
void  demosplbutton1init(DIL *B,void *pt) {
}
int  demobutton1callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type0 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);


  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton1init(DIN *B,void *pt) {
}
int  demobutton2callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type1 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton2init(DIN *B,void *pt) {
}
int  demobutton3callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type2 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton3init(DIN *B,void *pt) {
}
int  demobutton4callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type3 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton4init(DIN *B,void *pt) {
}
int  demobutton5callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type4 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton5init(DIN *B,void *pt) {
}
int  demobutton6callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  char *pt,*ptmp;;
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  DIX *X;DIY *Y;DICH *Ch;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  X = (DIX *) kgGetNamedWidget(Tmp,"Xbox");
  Y = (DIY *) kgGetNamedWidget(Tmp,"Ybox");
  Ch = (DICH *) kgGetNamedWidget(Tmp,"Chbox");
  kgWrite(s,"You pressed type5 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
	    if(strlen(myFolder)==1) break;
	    pt=myFolder+1;
	    while((ptmp = strstr(pt,"/"))!= NULL) pt=ptmp+1;
	    pt--;
	    if( pt!=NULL) pt[0]='\0';
	    if(strlen(myFolder)<=1)strcpy(myFolder,"/");
	    ScrollWrite(myFolder);
            kgFreeThumbNails((ThumbNail **) (kgGetList(X)));
            kgFreeThumbNails((ThumbNail **) (kgGetList(Y)));
	    kgSetList(X,(void **) kgFolderThumbNails(myFolder));
            kgSetList(Y, (void **) kgMakeThumbNails(myFolder,64));
            kgUpdateWidget(X);
            kgUpdateWidget(Y);
            kgUpdateOn(Tmp);
      break;
  }
  return ret;
}
void  demobutton6init(DIN *B,void *pt) {
}
int  demobutton7callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type6 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton7init(DIN *B,void *pt) {
}
int  demobutton8callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type7 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton8init(DIN *B,void *pt) {
}
int  demobutton9callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type8 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton9init(DIN *B,void *pt) {
}
int  demobutton10callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type9 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton10init(DIN *B,void *pt) {
}
int  demobutton11callback(int butno,int i,void *Tmp) {
  /*********************************** 
    butno : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIN *B; 
  int n,ret =0; 
  D = (DIALOG *)Tmp;
  B = (DIN *)kgGetWidget(Tmp,i);
  n = B->nx*B->ny;
  DIS *s;
  s= (DIS *)kgGetNamedWidget(Tmp,"ScrollBox");
  kgWrite(s,"You pressed type10 button\n");
  kgUpdateWidget(s);
  kgUpdateOn(Tmp);
  switch(butno) {
    case 1: 
      break;
  }
  return ret;
}
void  demobutton11init(DIN *B,void *pt) {
}
int  demobrowser1callback(int item,int i,void *Tmp) {
  /*********************************** 
    item : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIW *B; 
  int ret=1; 
  D = (DIALOG *)Tmp;
  B = (DIW *) kgGetWidget(Tmp,i);
  InfoWrite("You selected DIW(pulldown menu)  item");
  switch(item) {
    case 1: 
      break;
  }
  return ret;
}
int  demotextbox1callback(int cellno,int i,void *Tmp) {
  /************************************************* 
   cellno: current cell counted along column strting with 0 
           ie 0 to (nx*ny-1) 
   i     : widget id starting from 0 
   Tmp   : Pointer to DIALOG 
   *************************************************/ 
  DIALOG *D;DIT *T;T_ELMT *e; 
  int ret=1;
  D = (DIALOG *)Tmp;
  T = (DIT *)kgGetWidget(Tmp,i);
  e = T->elmt;
  InfoWrite("you typed text box");
  return ret;
}
int  demotablebox1callback(int cellno,int i,void *Tmp) {
  /************************************************* 
   cellno: current cell counted along column strting with 0 
           ie 0 to (nx*ny-1) 
           However cellno got 2 special values
             1. SCROLL_DOWN a scrolldown action
             2. SCROLL_UP a scrolldown action
             which may be ignored or peocessed
   i     : widget id starting from 0 
   Tmp   : Pointer to DIALOG 
   *************************************************/ 
  DIALOG *D;DIT *T;T_ELMT *e; 
  int ret=1;
  float val0,val1,val2,val3,val4,val5;
  D = (DIALOG *)Tmp;
  T = (DIT *)kgGetWidget(Tmp,i);
  e = T->elmt;
  val0 = kgGetFloat(T,0);
  val1 = kgGetFloat(T,1);
  val2 = val0*val1;
  val3 = kgGetFloat(T,3);
  val4 = kgGetFloat(T,4);
  val5 = val3*val4;
  kgSetFloat(T,2,val2);
  kgSetFloat(T,5,val5);
  kgUpdateWidget(T);
  kgUpdateOn(Tmp);
  InfoWrite("you typed a table box");
  return ret;
}
int  demodslide1callback(int val,int i,void *Tmp) {
  /*********************************** 
    val : current value 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DID *SD;DIF *SF;  DIT *TB;
  int ret=1; 
  float  fval;
  D = (DIALOG *)Tmp;
  SD = (DID *) kgGetWidget(Tmp,i);
  SF = (DIF *) kgGetNamedWidget(Tmp,"Fslide");
  TB = (DIT *) kgGetNamedWidget(Tmp,"Tbbox");
  fval = kgGetFloat(TB,1);
  kgSetFloat(TB,0,(float)val);
//  kgSetFloat(TB,1,(float)fval);
  kgSetFloat(TB,2,(float)fval*val);
  kgUpdateWidget(TB);
  kgUpdateOn(Tmp);

  InfoWrite("you moved int slide");
  return ret;
}
int  demofslide1callback(double val,int i,void *Tmp) {
  /*********************************** 
    val : current value 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIF *F; DIT *TB;
  int ret=1; 
  float fval;
  D = (DIALOG *)Tmp;
  F = (DIF *) kgGetWidget(Tmp,i);
  TB = (DIT *) kgGetNamedWidget(Tmp,"Tbbox");
  fval = kgGetFloat(TB,0);
  kgSetFloat(TB,1,(float)val);
  kgSetFloat(TB,2,(float)fval*val);
  kgUpdateWidget(TB);
  kgUpdateOn(Tmp);
  InfoWrite("you moved float slide");
  return ret;
}
void demogbox1init(int i,void *Tmp) {
  /*********************************** 
    int routine for grahics area 
   ***********************************/ 
  DIALOG *D;void *pt;
  DIG *G;
  D = (DIALOG *)Tmp;
  pt = D->pt;
  G = D->d[i].g;
  G->D = (void *)(Tmp);
  kgUserFrame(G,0.0,0.0,100.0,100.0);
  return ;
}
int  demobrowser2callback(int item,int i,void *Tmp) {
  /*********************************** 
    item : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIE *E;void *pt; 
  int ret=1; 
  D = (DIALOG *)Tmp;
  pt = D->pt;
  E = (DIE *)kgGetWidget(Tmp,i);
  InfoWrite("Pressed DIE");
  ScrollWrite(" ");
  ScrollWrite("You made a selection in DIE ");
  ScrollWrite("(menu of character Strings)");
  ScrollWrite("You can customise DIE ");
  switch(item) {
    case 1: 
      break;
  }
  return ret;
}
void  demobrowser2init(DIE *E,void *pt) {
}
void  demobrowser3init(DIS *S,void *pt) {
}
int  demodslide2callback(int val,int i,void *Tmp) {
  /*********************************** 
    val : current value 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIHB *SD; 
  int ret=1; 
  DIO *O;
  DIT *T;
  D = (DIALOG *)Tmp;
  SD = (DIHB *) kgGetWidget(Tmp,i);
  O = (DIO *)kgGetNamedWidget(Tmp,"Obox");
  T = (DIT *)kgGetNamedWidget(Tmp,"Tbox");
  kgSetProgressBar(O,val);
  kgSetInt(T,0,val);
  kgUpdateWidget(T);
  kgUpdateOn(Tmp);
  InfoWrite("You a moved DIHB (a tyoe of slide}");
  ScrollWrite(" ");
  ScrollWrite("DIHB slide");
  ScrollWrite("You have to set its range");
  ScrollWrite("in a way it is way to input a value");
  ScrollWrite("The look of DIHB can be changed");
  return ret;
}
int  demobrowser4callback(int item,int i,void *Tmp) {
  /*********************************** 
    item : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIX *X;void *pt; DIY *Y;DICH *Ch;
  char buff[300];
  int ret=1; 
  ThumbNail **list;
  ThumbNail *th;
  D = (DIALOG *)Tmp;
  pt = D->pt;
  X = (DIX *)kgGetWidget(Tmp,i);
  InfoWrite("You picked item in DIX (check box)");
  ScrollWrite(" ");
  ScrollWrite(" DIX (check box)");
  ScrollWrite("Check Box used ThumNails as its items");
  ScrollWrite("ThumbNails got an image and a name also a switch");
  ScrollWrite("But image/name can be set as NULL");
  ScrollWrite("there are few helper routines to make ThimbNails");
  ScrollWrite("Now it lists Folders in the current folder");
  list = (ThumbNail **)kgGetList(X);
  if(list == NULL) return ret;
  th = list[item-1];
  strcpy(buff,myFolder);
  strcat(buff,"/");
  strcat(buff,th->name);
  strcpy(myFolder,buff);
  Y = (DIY *) kgGetNamedWidget(Tmp,"Ybox");
  Ch = (DICH *) kgGetNamedWidget(Tmp,"Chbox");
  
  kgFreeThumbNails((ThumbNail **) (kgGetList(X)));
  kgSetList(X,(void **) kgFolderThumbNails(myFolder));
  kgFreeThumbNails((ThumbNail **) (kgGetList(Y)));
  kgSetList(Y,(void **) kgMakeThumbNails(myFolder,64));
  kgUpdateWidget(X);
  kgUpdateWidget(Y);
  kgUpdateOn(Tmp);
  switch(item) {
    case 1: 

      break;
  }
  return ret;
}
void  demobrowser4init(DIX *X,void *pt) {
 // One may setup browser list here by setting X->list
 // if it need to be freed set it as X->pt also
//     strcpy(myFolder,"/usr/share/icons/CratOS_lion-icons/apps/scalable");
//     strcpy(myFolder,"/usr/share");
//     X->list = (void **) kgFolderThumbNails(myFolder);
       kgSetList(X,(void **)kgFolderThumbNails(myFolder));
}
int  demobrowser5callback(int item,int i,void *Tmp) {
  /*********************************** 
    item : selected item (1 to max_item)  not any specific relevence
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIRA *R;DIALOG *D;void *pt; 
  ThumbNail **th; 
  int ret=1; 
  D = (DIALOG *)Tmp;
  pt = D->pt;
  R = (DIRA *)kgGetWidget(Tmp,i);
  th = (ThumbNail **)kgGetList(R);;
  InfoWrite("This is DIRA (radio button)");
  ScrollWrite(" ");
  ScrollWrite("Radio buttons (DIRA) to select one");
  ScrollWrite("It also uses ThimbNails , but ignores images");
  ScrollWrite("Now you have selected an item");
  return ret;
}
void  demobrowser5init(DIRA *R,void *pt) {
}
int  demobrowser6callback(int item,int i,void *Tmp) {
  /*********************************** 
    item : selected item (1 to max_item)  not any specific relevence
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DICH *C;DIALOG *D;void *pt; 
  ThumbNail **th; 
  int ret=1; 
  D = (DIALOG *)Tmp;
  pt = D->pt;
  C = (DICH *)kgGetWidget(Tmp,i);
  th = (ThumbNail **)kgGetList(C);
  InfoWrite(" Check menui(DICH) using ThumbNails");
  ScrollWrite(" ");
  ScrollWrite( " Check Menu (DICH) ");
  ScrollWrite("This Check menu is using ThumbNails");
  ScrollWrite(" it can be set for single or multiple items");
  ScrollWrite(" Now it is set for Files");

  return ret;
}
void  demobrowser6init(DICH *C,void *pt) {

}
int  demobrowser7callback(int item,int i,void *Tmp) {
  DIALOG *D;DIY *Y;void *pt; 
  /*********************************** 
    item : selected item (1 to max_item) 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  int ret=1,x,y; 
  D = (DIALOG *)Tmp;
  ThumbNail **TH,*th;
  pt = D->pt;
  Y = (DIY *)kgGetWidget(Tmp,i);
  DIT *wid;
  InfoWrite("ThumbNail browser (DIY)");
  ScrollWrite("  ");
  ScrollWrite("ThumbNail browser (DIY");
  ScrollWrite("DIY is another brower for ThumbNails");
  ScrollWrite("can select multiple items");
  ScrollWrite("One can program it to drag items");
#if 0
  TH = (ThumbNail **)kgGetList(Y);
  th = kgCopyThumbNail(TH[item-1]);
  kgDeleteThumbNail(Y,item-1);
  kgInsertThumbNail(Y,th,0);
  kgUpdateWidget(Y);
  kgUpdateOn(Tmp);
#endif
#if 1
  if(kgDragThumbNail(Y,item-1,&x,&y)) {
     wid = (DIT *)kgGetLocationWidget(Tmp,x,y);
     if(wid != NULL) {
//	     if(wid->code=='p') {
	     if(kgCheckWidgetName(wid,"PicBox")) {
		     ThumbNail *thtmp;
		     thtmp= ((ThumbNail **)kgGetList(Y))[item-1];
		     sprintf(buf,"%-s/%s",myFolder,thtmp->name);
		     DrawBox(buf);
	     }
	     else {
		     if(kgCheckWidgetName(wid,"Ybox")) {
		       int pos=-1;
		       pos = kgGetThumbNailItem(Y,x,y);
		       if(pos != item-1) {
			     kgMoveThumbNail(Y,item-1,pos);
			     kgUpdateWidget(Y);
			     kgUpdateOn(Tmp);
	  	       }
		     }
	     }
     }
  }
#endif
  switch(item) {
    case 1: 
      break;
  }
  return ret;
}
void  demobrowser7init(DIY *Y,void *pt) {
 // One may setup browser list here by setting Y->list
 // if it need to be freed set it as Y->pt also
//     Y->list = (void **) kgFileThumbNails(myFolder,"*");
       kgFreeThumbNails((ThumbNail **)kgGetList(Y));
       kgSetList(Y, (void **)kgMakeThumbNails(myFolder,64));
#if 0
       kgInsertThumbNail(Y,kgPickThumbNail(Y,1),0);
       kgSortList(Y);
       kgDeleteThumbNail(Y,2);
#endif
}
int  demovertscroll1callback(double val,int i,void *Tmp) {
  /*********************************** 
    val : current value 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIV *V; 
  int ret=1; 
  D = (DIALOG *)Tmp;
  V = (DIV *) kgGetWidget(Tmp,i);

  InfoWrite("DIV, vertical scroll,");
  ScrollWrite(" ");
  ScrollWrite("Vertical Scroll (DIV)");
  ScrollWrite("You have set it and use it");
  ScrollWrite("For example to Scroll an image");
  return ret;
}
int  demohorizscroll1callback(double val,int i,void *Tmp) {
  /*********************************** 
    val : current value 
    i :  Index of Widget  (0 to max_widgets-1) 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  DIALOG *D;DIZ *Z; 
  int ret=1; 
  D = (DIALOG *)Tmp;
  Z = (DIZ *) kgGetWidget(Tmp,i);
  InfoWrite("DIZ, horizondal  scroll,");
  ScrollWrite("  ");
  ScrollWrite("DIZ, horizondal  scroll,");
  ScrollWrite("You have set it and use it");
  ScrollWrite("For example to Scroll an image");
  return ret;
}
int demoinit(void *Tmp) {
  /*********************************** 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  /* you add any initialisation here */
  int ret = 1;
  DIALOG *D;void *pt;
  D = (DIALOG *)Tmp;
  pt = D->pt;
  return ret;
}
int democleanup(void *Tmp) {
  /* you add any cleanup/mem free here */
  /*********************************** 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  int ret = 1;
  DIALOG *D;void *pt;
  D = (DIALOG *)Tmp;
  pt = D->pt;
  return ret;
}
int Modifydemo(void *Tmp,int GrpId) {
  DIALOG *D;
  D = (DIALOG *)Tmp;
  DIA *d;
  int i,n;
  d = D->d;
  i=0;while(d[i].t!= NULL) {;
     i++;
  };
  n=1;
  return GrpId;
}

int demoCallBack(void *Tmp,void *tmp) {
  /*********************************** 
    Tmp :  Pointer to DIALOG  
    tmp :  Pointer to KBEVENT  
   ***********************************/ 
  int ret = 0;
  DIALOG *D;
  KBEVENT *kbe;
  D = (DIALOG *)Tmp;
  DIT *T;
  kbe = (KBEVENT *)tmp;
  T = (DIT *)kgGetClickedWidget(Tmp);
  if(kbe->event ==1) {
    if(kbe->button ==1) {
     if(T!= NULL) {
	  sprintf(buf,"code= %c\n",T->code);
	  InfoWrite(buf);
	  switch (T->code) {
		  case 's':
			  MsgWrite("You have Pressed Message Scroll(DIS)");
			  InfoWrite("You have Pressed Message Scroll(DIS)");
			  break;
		  case 'p':
			  strcpy(buf,"");
			  InfoWrite("PICK AN IMAGE FILE");
//			  kgFolderBrowser(Tmp,20,20,buf, "*");
			  kgPickImage(Tmp,100,100,buf);
                          DrawBox(buf);
			  break;
		  case 'g':
			  InfoWrite("You clicked drawing area(DIG)");
			  kgDrawingTool(kgGetNamedWidget(Tmp,"Gbox"));
			  break;
		  default:
	                   InfoWrite("You have clicked a Widget");
	                   InfoWrite("May be an output Widget");
			  break;
	  }
        }
        else {
          ScrollWrite("  ");
          ScrollWrite("This is the  default call back");
          ScrollWrite("used it if no other call back proper or NULL");
          ScrollWrite("You can use it programm arbitary point click");
        }
      }
  }
  return ret;
}
int demoResizeCallBack(void *Tmp) {
  /*********************************** 
    Tmp :  Pointer to DIALOG  
   ***********************************/ 
  int ret = 0;
  int xres,yres,dx,dy;
  DIALOG *D;
  D = (DIALOG *)Tmp;
  kgGetWindowSize(D,&xres,&yres);
  dx = xres - D->xl;
  dy = yres - D->yl;
  /* extra code */
  D->xl= xres;
  D->yl= yres;
  kgRedrawDialog(D);
  return ret;
}
int demoWaitCallBack(void *Tmp) {
  /*********************************** 
    Tmp :  Pointer to DIALOG  
    Called while waiting for event  
    return value 1 will close the the UI  
   ***********************************/ 
  int ret = 0;
  static int entry=0;
  static DIM *sp=NULL;
  static DIM *msg=NULL;
  static DIM *msgb=NULL;
  static int Minute=-1;
  char buff[100];
  static char *days[7]={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
  static char *months[12]={"Jan","Feb","Mar","Apr","May","Jun","Jul", "Aug","Sep","Oct","Nov","Dec"};
  time_t tp,t;
  struct tm *dt;
  int odate=-1,ndate;
  usleep(10000);
  t=time(&tp);
  dt = localtime(&t);
  entry = (++entry)%100;
  if((entry!=0)&&(entry!=50)) return ret;
#if 0
  if( dt->tm_min != Minute ) {
  }
#endif
  if( entry ) {
    if(sp == NULL){
	    sp = kgGetNamedWidget(Tmp,"Splash");
	    msg = kgGetNamedWidget(Tmp,"MsgBox");
	    msgb = kgGetNamedWidget(Tmp,"MsgbBox");
    }
    ndate = dt->tm_year*10000+dt->tm_mon*100+dt->tm_mday;
    if(ndate != odate) {
	    odate=ndate;
	    sprintf(buff,"%d %-s",dt->tm_year+1900,months[dt->tm_mon]);
	    kgWrite(msg,buff);
	    sprintf(buff,"%d %-s",dt->tm_mday,days[dt->tm_wday]);
	    kgWrite(msgb,buff);
    }
    Minute= dt->tm_min;
    sprintf(buff,"%2.2d",dt->tm_hour);
    strcat(buff,"!%:!%");
    sprintf(buff+strlen(buff),"%2.2d",dt->tm_min);
    kgWrite(sp,buff);
  }
  else {
    if(sp == NULL) sp = kgGetNamedWidget(Tmp,"Splash");
    Minute= dt->tm_min;
    sprintf(buff,"%2.2d",dt->tm_hour);
    strcat(buff,"!% !%");
    sprintf(buff+strlen(buff),"%2.2d",dt->tm_min);
    kgWrite(sp,buff);
  }

  return ret;
}
