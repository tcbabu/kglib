#include <kulina.h>
#include "demoCallbacks.h"
#include "Gclr.c"
int demoGroup( DIALOG *D,void **v,void *pt) {
  int GrpId=0,oitems=0,i,j;
  DIA *d=NULL,*dtmp;
  BUT_STR  *butn0=NULL; 
  butn0= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn0[0].sw=1;
  strcpy(butn0[0].title,(char *)"Spl but1");
  butn0[0].xpmn=NULL;
  butn0[0].xpmp=NULL;
  butn0[0].xpmh=NULL;
  butn0[0].bkgr=-1;
  butn0[0].butncode='';
  DIL h0 = { 
    'h',
    656,747,  
    738,780,
    2,0,  
    72, 
    25, 
    1,1, 
    2,0.500000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn0, 
    demosplbutton1callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(h0.Wid,(char *)"demoWidget1");
  h0.item = -1;
  BUT_STR  *butn1=NULL; 
  butn1= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn1[0].sw=1;
  strcpy(butn1[0].title,(char *)"but type0");
  butn1[0].xpmn=NULL;
  butn1[0].xpmp=NULL;
  butn1[0].xpmh=NULL;
  butn1[0].bkgr=-1;
  butn1[0].butncode='';
  DIN b1 = { 
    'n',
    336,646,  
    411,737,
    2,2,  
    64, 
    64, 
    1,1, 
    0,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn1, 
    demobutton1callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b1.Wid,(char *)"demoWidget2");
  b1.item = -1;
  BUT_STR  *butn2=NULL; 
  butn2= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn2[0].sw=1;
  strcpy(butn2[0].title,(char *)"but type2");
  butn2[0].xpmn=NULL;
  butn2[0].xpmp=NULL;
  butn2[0].xpmh=NULL;
  butn2[0].bkgr=-1;
  butn2[0].butncode='';
  DIN b2 = { 
    'n',
    496,644,  
    570,718,
    2,2,  
    64, 
    64, 
    1,1, 
    2,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn2, 
    demobutton2callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b2.Wid,(char *)"demoWidget4");
  b2.item = -1;
  BUT_STR  *butn3=NULL; 
  butn3= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn3[0].sw=1;
  strcpy(butn3[0].title,(char *)"but type1");
  butn3[0].xpmn=NULL;
  butn3[0].xpmp=NULL;
  butn3[0].xpmh=NULL;
  butn3[0].bkgr=-1;
  butn3[0].butncode='';
  DIN b3 = { 
    'n',
    416,646,  
    490,720,
    2,2,  
    64, 
    64, 
    1,1, 
    1,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn3, 
    demobutton3callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b3.Wid,(char *)"demoWidget5");
  b3.item = -1;
  BUT_STR  *butn4=NULL; 
  butn4= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn4[0].sw=1;
  strcpy(butn4[0].title,(char *)"but type3");
  butn4[0].xpmn=NULL;
  butn4[0].xpmp=NULL;
  butn4[0].xpmh=NULL;
  butn4[0].bkgr=-1;
  butn4[0].butncode='';
  DIN b4 = { 
    'n',
    576,645,  
    650,719,
    2,2,  
    64, 
    64, 
    1,1, 
    3,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn4, 
    demobutton4callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b4.Wid,(char *)"demoWidget6");
  b4.item = -1;
  BUT_STR  *butn5=NULL; 
  butn5= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn5[0].sw=1;
  strcpy(butn5[0].title,(char *)"but type4");
  butn5[0].xpmn=NULL;
  butn5[0].xpmp=NULL;
  butn5[0].xpmh=NULL;
  butn5[0].bkgr=-1;
  butn5[0].butncode='';
  DIN b5 = { 
    'n',
    661,645,  
    735,719,
    2,2,  
    64, 
    64, 
    1,1, 
    4,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn5, 
    demobutton5callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b5.Wid,(char *)"demoWidget7");
  b5.item = -1;
  BUT_STR  *butn6=NULL; 
  butn6= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn6[0].sw=1;
  strcpy(butn6[0].title,(char *)"but type5");
  butn6[0].xpmn=NULL;
  butn6[0].xpmp=NULL;
  butn6[0].xpmh=NULL;
  butn6[0].bkgr=-1;
  butn6[0].butncode='';
  DIN b6 = { 
    'n',
    746,644,  
    820,718,
    2,2,  
    64, 
    64, 
    1,1, 
    5,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn6, 
    demobutton6callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b6.Wid,(char *)"demoWidget8");
  b6.item = -1;
  BUT_STR  *butn7=NULL; 
  butn7= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn7[0].sw=1;
  strcpy(butn7[0].title,(char *)"but type6");
  butn7[0].xpmn=NULL;
  butn7[0].xpmp=NULL;
  butn7[0].xpmh=NULL;
  butn7[0].bkgr=-1;
  butn7[0].butncode='';
  DIN b7 = { 
    'n',
    826,643,  
    900,717,
    2,2,  
    64, 
    64, 
    1,1, 
    6,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn7, 
    demobutton7callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b7.Wid,(char *)"demoWidget9");
  b7.item = -1;
  BUT_STR  *butn8=NULL; 
  butn8= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn8[0].sw=1;
  strcpy(butn8[0].title,(char *)"but type7");
  butn8[0].xpmn=NULL;
  butn8[0].xpmp=NULL;
  butn8[0].xpmh=NULL;
  butn8[0].bkgr=-1;
  butn8[0].butncode='';
  DIN b8 = { 
    'n',
    901,643,  
    975,717,
    2,2,  
    64, 
    64, 
    1,1, 
    7,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn8, 
    demobutton8callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b8.Wid,(char *)"demoWidget10");
  b8.item = -1;
  BUT_STR  *butn9=NULL; 
  butn9= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn9[0].sw=1;
  strcpy(butn9[0].title,(char *)"but type8");
  butn9[0].xpmn=NULL;
  butn9[0].xpmp=NULL;
  butn9[0].xpmh=NULL;
  butn9[0].bkgr=-1;
  butn9[0].butncode='';
  DIN b9 = { 
    'n',
    981,644,  
    1055,718,
    2,2,  
    64, 
    64, 
    1,1, 
    8,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn9, 
    demobutton9callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b9.Wid,(char *)"demoWidget11");
  b9.item = -1;
  BUT_STR  *butn10=NULL; 
  butn10= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn10[0].sw=1;
  strcpy(butn10[0].title,(char *)"but type9");
  butn10[0].xpmn=NULL;
  butn10[0].xpmp=NULL;
  butn10[0].xpmh=NULL;
  butn10[0].bkgr=-1;
  butn10[0].butncode='';
  DIN b10 = { 
    'n',
    1062,644,  
    1136,718,
    2,2,  
    64, 
    64, 
    1,1, 
    9,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn10, 
    demobutton10callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b10.Wid,(char *)"demoWidget12");
  b10.item = -1;
  BUT_STR  *butn11=NULL; 
  butn11= (BUT_STR *)malloc(sizeof(BUT_STR)*1);
  butn11[0].sw=1;
  strcpy(butn11[0].title,(char *)"but type10");
  butn11[0].xpmn=NULL;
  butn11[0].xpmp=NULL;
  butn11[0].xpmh=NULL;
  butn11[0].bkgr=-1;
  butn11[0].butncode='';
  DIN b11 = { 
    'n',
    1142,631,  
    1223,739,
    2,2,  
    64, 
    64, 
    1,1, 
    10,0.150000,0,0,0,1, /* button type and roundinfg factor(0-0.5),bordr,hide ,nodrawbkgr*/
 
    butn11, 
    demobutton11callback, /*  Callbak */
      NULL  /* any args */
  };
  strcpy(b11.Wid,(char *)"demoWidget13");
  b11.item = -1;
  char **menu12 ; 
  menu12= (char **)malloc(sizeof(char *)*7);
  menu12[6]=NULL;
  menu12[0]=(char *)malloc(4);
  strcpy(menu12[0],(char *)"one");
  menu12[1]=(char *)malloc(4);
  strcpy(menu12[1],(char *)"two");
  menu12[2]=(char *)malloc(6);
  strcpy(menu12[2],(char *)"three");
  menu12[3]=(char *)malloc(5);
  strcpy(menu12[3],(char *)"four");
  menu12[4]=(char *)malloc(5);
  strcpy(menu12[4],(char *)"five");
  menu12[5]=(char *)malloc(4);
  strcpy(menu12[5],(char *)"six");
  char *prompt12 ; 
  prompt12=(char *)malloc(1);
  strcpy(prompt12,(char *)"");
  DIW w12 = { 
    'w',
    96,421,  
    320,475,   
    4,  
    (int *)v[0],
    prompt12 ,
    menu12 ,
    NULL,demobrowser1callback, /* *args, callback */
    0 
  };
  strcpy(w12.Wid,(char *)"demoWidget14");
  w12.item = -1;
  T_ELMT *e13  ; 
  e13 =(T_ELMT *)malloc(sizeof(T_ELMT)*1);
  e13[0].fmt = (char *)malloc(11);
  strcpy(e13[0].fmt,(char *)"Hellow%10d");
  e13[0].v=(void *)v[1];
  e13[0].sw=1;
  e13[0].noecho=0;
  e13[0].img=NULL;
  DIT t13 = { 
    't',
    338,436,  
    535,470,
    20, 
    1,1, 
    e13,
    1,1,
    NULL,demotextbox1callback,1,0,18,9 /* args,Call back */
  };
  strcpy(t13.Wid,(char *)"demoWidget16");
  t13.pt=NULL;
  t13.type = 0;
  t13.item = -1;
  T_ELMT *e14  ; 
  e14 =(T_ELMT *)malloc(sizeof(T_ELMT)*6);
  e14[0].fmt = (char *)malloc(5);
  strcpy(e14[0].fmt,(char *)"%10d");
  e14[0].v=(void *)v[2];
  e14[0].sw=1;
  e14[0].noecho=0;
  e14[0].img=NULL;
  e14[1].fmt = (char *)malloc(5);
  strcpy(e14[1].fmt,(char *)"%10d");
  e14[1].v=(void *)v[3];
  e14[1].sw=1;
  e14[1].noecho=0;
  e14[1].img=NULL;
  e14[2].fmt = (char *)malloc(5);
  strcpy(e14[2].fmt,(char *)"%10d");
  e14[2].v=(void *)v[4];
  e14[2].sw=0;
  e14[2].noecho=0;
  e14[2].img=NULL;
  e14[3].fmt = (char *)malloc(5);
  strcpy(e14[3].fmt,(char *)"%10d");
  e14[3].v=(void *)v[5];
  e14[3].sw=1;
  e14[3].noecho=0;
  e14[3].img=NULL;
  e14[4].fmt = (char *)malloc(5);
  strcpy(e14[4].fmt,(char *)"%10d");
  e14[4].v=(void *)v[6];
  e14[4].sw=1;
  e14[4].noecho=0;
  e14[4].img=NULL;
  e14[5].fmt = (char *)malloc(5);
  strcpy(e14[5].fmt,(char *)"%10d");
  e14[5].v=(void *)v[7];
  e14[5].sw=0;
  e14[5].noecho=0;
  e14[5].img=NULL;
  DIT T14 = { 
    'T',
    533,421,  
    905,478,
    24, 
    3,2, 
    e14,
    1,1,
    NULL,demotablebox1callback,1,0,18,9 /* args,Call back */
  };
  strcpy(T14.Wid,(char *)"demoWidget17");
  T14.pt=NULL;
  T14.type = 0;
  T14.item = -1;
  DID d15 = { 
    'd',
    174,366,  
    325,412,   
    0,100,  
    101,  
    (int *)v[8],
    NULL,
    NULL,demodslide1callback /* *args, callback */
  };
  strcpy(d15.Wid,(char *)"demoWidget18");
  d15.item = -1;
  DIF f16 = { 
    'f',
    15,366,  
    165,412,   
    1.000000,100.000000,  
    100,  
    (double *)v[9],
    NULL,
    NULL,demofslide1callback /* *args, callback */
  };
  strcpy(f16.Wid,(char *)"demoWidget19");
  f16.item = -1;
  char *xpm17;// Pixmap info
  xpm17 = (char *)malloc(3);
  strcpy(xpm17, (char *)"##");
  DIP p17 = { 
    'p',
    31,484,  
    307,654,  
    (void *)xpm17,
    -1, /* bkgr colour */ 
      3,0,0.000000 /* border hide transparency*/ 
  };
  strcpy(p17.Wid,(char *)"PicBox");
  p17.item = -1;
  char *xpm18=   NULL; /* pixmap info */ 
  DIG g18 = { 
    'g',
    400,16,  
    1065,365,  
    (void *)xpm18,
    0, /* bkgr colour */ 
    demogbox1init,/* void *initgraph(int,void *)  */ 
    NULL,0,0 /* *data border hide*/
  };
  strcpy(g18.Wid,(char *)"demoWidget21");
  g18.item = -1;
  DII i19 = { 
    'i',
    1101,16,  
    1395,366,  
    31,15,0   
  };
  strcpy(i19.Wid,(char *)"InfoBox");
  i19.item = -1;
  DIM m20 = { 
    'm',
    455,376,  
    555,400,  
    1,0  
  };
  strncpy(m20.msg,(char *)"Message",499);
  strcpy(m20.Wid,(char *)"MsgBox");
  m20.item = -1;
  DIM m21 = { 
    'M',
    675,381,  
    875,421,  
    0,0  
  };
  strncpy(m21.msg,(char *)" Hellow",499);
  strcpy(m21.Wid,(char *)"demoWidget24");
  m21.item = -1;
  char **menu22 ; 
  menu22= (char **)malloc(sizeof(char *)*7);
  menu22[6]=NULL;
  menu22[0]=(char *)malloc(4);
  strcpy(menu22[0],(char *)"one");
  menu22[1]=(char *)malloc(4);
  strcpy(menu22[1],(char *)"two");
  menu22[2]=(char *)malloc(6);
  strcpy(menu22[2],(char *)"three");
  menu22[3]=(char *)malloc(5);
  strcpy(menu22[3],(char *)"four");
  menu22[4]=(char *)malloc(5);
  strcpy(menu22[4],(char *)"five");
  menu22[5]=(char *)malloc(4);
  strcpy(menu22[5],(char *)"six");
  DIE e22 = { 
    'e',
    310,486,  
    465,637,   
    6,  
    (int *)v[10],
    NULL,
    menu22 ,
    NULL,demobrowser2callback, /* *args, callback */
    20,6,22,1,1,1,0 
  };
  strcpy(e22.Wid,(char *)"demoWidget25");
  e22.item = -1;
  DIS s23 = { 
    's',
    14,16,  
    395,364,   
    16,  
    NULL,
    NULL,
    NULL ,
    NULL,NULL, /* *args, callback */
    20,6,22,1,1,1,0
//     line width,offset (not used),scroll width,highlight item(not used)
//     border on/off,bkgr on/off,hide on/off
//     uses Gclr items: msg_fill,msg_char,msg_bodr,scroll_fill,scroll_dim,scroll_vbright)
  };
  strcpy(s23.Wid,(char *)"ScrollBox");
  s23.item = -1;
  DIHB d24 = { 
    'P',
    329,376,  
    440,401,   
    0,100,  
    76,  
    (int *)v[11],
    NULL,
    NULL,demodslide2callback, /* *args, callback */
    0,0,2,-1, /* bordr,hide,type,color */
  };
  strcpy(d24.Wid,(char *)"demoWidget27");
  d24.item = -1;
  DIX x25 = { 
    'x',
    765,486,  
    915,633,   
    10,2,  
    108, 
    25, 
    1,1122944464, 
    0,5, 
    (int *)v[12], 
    NULL, 
    NULL, 
    NULL,demobrowser4callback, /* *args, callback */
    6,  /* Border Offset  */
     22,  /* Scroll width  */
     0,  /* Type  */
     1, /* item highlight */
    1, /* bordr */
    1, /* bkgr */
    0  /* =1 hide  */
   };
  strcpy(x25.Wid,(char *)"demoWidget28");
  x25.item = -1;
  char *menu26[]  = { 
    (char *)"one",
    (char *)"two",
    (char *)"three",
    (char *)"four",
    NULL 
  };
  ThumbNail **th0 ;
  DIRA r26 = { 
    'r',
    467,486,  
    610,635,   
    8,0,  
    90, 
    25, 
    1,4, 
    -2302756,4, 
    (int *)v[13], 
    NULL, 
    NULL ,
    NULL,demobrowser5callback, /* *args, callback */
    6,  /* Border Offset  */
     22,  /* Scroll width  */
     0,  /* Type  */
     0, /* item highlight */
    1, /* bordr */
    0, /* bkgr */
    0  /* =1 hide  */
   };
  th0 = (ThumbNail **)kgStringToThumbNails((char **)menu26);
  r26.list=(void **)th0;
  strcpy(r26.Wid,(char *)"demoWidget29");
  r26.item = -1;
  char *menu27[]  = { 
    (char *)"one",
    (char *)"two",
    (char *)"three",
    (char *)"four",
    NULL 
  };
  ThumbNail **th1 ;
  DICH c27 = { 
    'c',
    619,486,  
    760,634,   
    8,0,  
    90, 
    25, 
    1,4, 
    9856829,4, 
    (int *)v[14], 
    NULL, 
    NULL, 
    NULL,demobrowser6callback, /* *args, callback */
    6,  /* Border Offset  */
     22,  /* Scroll width  */
     0,  /* Type  */
     0, /* item highlight */
    1, /* bordr */
    0, /* bkgr */
    0  /* =1 hide  */
   };
  th1 = (ThumbNail **)kgStringToThumbNails((char **)menu27);
  c27.list=(void **)th1;
  strcpy(c27.Wid,(char *)"demoWidget30");
  c27.item = -1;
  DIY y28 = { 
    'y',
    916,377,  
    1403,628,   
    8,20,  
    64, 
    64, 
    1,1122944464, 
    0,2, 
    (int *)v[15], 
    NULL, 
    NULL, 
    NULL,demobrowser7callback, /* *args, callback */
    6,  /* Border Offset  */
     22,  /* Scroll width  */
     0,  /* Type  */
     1, /* item highlight */
    1, /* bordr */
    1, /* bkgr */
    0  /* =1 hide  */
   };
  strcpy(y28.Wid,(char *)"demoWidget34");
  y28.item = -1;
  DIO o29 = { 
    'o',
    326,411,  
    530,431,  
    0,50,0,0,-1,0  
       //hide,percent,border,type,color,direction 
  };
  strcpy(o29.Wid,(char *)"demoWidget35");
  o29.item = -1;
  DIV v30 = { 
    'v',
    9,476,  
    29,680,  
    0,  
    100.000000,0.000000,5.000000,  
    NULL,demovertscroll1callback /* *args, callback */
  };
  strcpy(v30.Wid,(char *)"demoWidget36");
  v30.item = -1;
  DIZ z31 = { 
    'z',
    36,660,  
    316,682,  
    0,  
    100.000000,0.000000,5.000000,  
    NULL,demohorizscroll1callback /* *args, callback */
  };
  strcpy(z31.Wid,(char *)"demoWidget37");
  z31.item = -1;
  DIM m32 = { 
    'B',
    565,376,  
    665,400,  
    0,0  
  };
  strncpy(m32.msg,(char *)"Message Box(B)",499);
  strcpy(m32.Wid,(char *)"demoWidget38");
  m32.item = -1;
  dtmp = D->d;
  i=0;
  if(dtmp!= NULL) while(dtmp[i].t!=NULL)i++;
  dtmp = (DIA *)realloc(dtmp,sizeof(DIA )*(i+34));
  d =dtmp+i; 
  d[33].t=NULL;
  d[0].t = (DIT *)malloc(sizeof(DIL));
  *d[0].h = h0;
  d[0].h->item = -1;
  demosplbutton1init(d[0].h,pt) ;
  d[1].t = (DIT *)malloc(sizeof(DIN));
  *d[1].N = b1;
  d[1].N->item = -1;
  demobutton1init(d[1].N,pt) ;
  d[2].t = (DIT *)malloc(sizeof(DIN));
  *d[2].N = b2;
  d[2].N->item = -1;
  demobutton2init(d[2].N,pt) ;
  d[3].t = (DIT *)malloc(sizeof(DIN));
  *d[3].N = b3;
  d[3].N->item = -1;
  demobutton3init(d[3].N,pt) ;
  d[4].t = (DIT *)malloc(sizeof(DIN));
  *d[4].N = b4;
  d[4].N->item = -1;
  demobutton4init(d[4].N,pt) ;
  d[5].t = (DIT *)malloc(sizeof(DIN));
  *d[5].N = b5;
  d[5].N->item = -1;
  demobutton5init(d[5].N,pt) ;
  d[6].t = (DIT *)malloc(sizeof(DIN));
  *d[6].N = b6;
  d[6].N->item = -1;
  demobutton6init(d[6].N,pt) ;
  d[7].t = (DIT *)malloc(sizeof(DIN));
  *d[7].N = b7;
  d[7].N->item = -1;
  demobutton7init(d[7].N,pt) ;
  d[8].t = (DIT *)malloc(sizeof(DIN));
  *d[8].N = b8;
  d[8].N->item = -1;
  demobutton8init(d[8].N,pt) ;
  d[9].t = (DIT *)malloc(sizeof(DIN));
  *d[9].N = b9;
  d[9].N->item = -1;
  demobutton9init(d[9].N,pt) ;
  d[10].t = (DIT *)malloc(sizeof(DIN));
  *d[10].N = b10;
  d[10].N->item = -1;
  demobutton10init(d[10].N,pt) ;
  d[11].t = (DIT *)malloc(sizeof(DIN));
  *d[11].N = b11;
  d[11].N->item = -1;
  demobutton11init(d[11].N,pt) ;
  d[12].t = (DIT *)malloc(sizeof(DIW));
  *d[12].w = w12;
  d[12].w->item = -1;
  d[13].t = (DIT *)malloc(sizeof(DIT));
  *d[13].t = t13;
  d[13].t->item = -1;
  d[14].t = (DIT *)malloc(sizeof(DIT));
  *d[14].t = T14;
  d[14].t->item = -1;
  d[15].t = (DIT *)malloc(sizeof(DID));
  *d[15].d = d15;
  d[15].d->item = -1;
  d[16].t = (DIT *)malloc(sizeof(DIF));
  *d[16].f = f16;
  d[16].f->item = -1;
  d[17].t = (DIT *)malloc(sizeof(DIP));
  *d[17].p = p17;
  d[17].p->item = -1;
  d[18].t = (DIT *)malloc(sizeof(DIG));
  *d[18].g = g18;
  d[18].g->item = -1;
  d[19].t = (DIT *)malloc(sizeof(DII));
  *d[19].i = i19;
  d[19].i->item = -1;
  d[20].t = (DIT *)malloc(sizeof(DIM));
  *d[20].m = m20;
  d[20].m->item = -1;
  d[21].t = (DIT *)malloc(sizeof(DIM));
  *d[21].m = m21;
  d[21].m->item = -1;
  d[22].t = (DIT *)malloc(sizeof(DIE));
  *d[22].e = e22;
  d[22].e->item = -1;
  d[23].t = (DIT *)malloc(sizeof(DIS));
  *d[23].s = s23;
  d[23].s->item = -1;
  demobrowser3init(d[23].s,pt) ;
  d[24].t = (DIT *)malloc(sizeof(DIHB));
  *d[24].B = d24;
  d[24].B->item = -1;
  d[25].t = (DIT *)malloc(sizeof(DIX));
  *d[25].x = x25;
  d[25].x->item = -1;
  demobrowser4init(d[25].x,pt) ;
  d[26].t = (DIT *)malloc(sizeof(DIRA));
  *d[26].r = r26;
  d[26].r->item = -1;
  demobrowser5init(d[26].r,pt) ;
  d[27].t = (DIT *)malloc(sizeof(DICH));
  *d[27].c = c27;
  d[27].c->item = -1;
  demobrowser6init(d[27].c,pt) ;
  d[28].t = (DIT *)malloc(sizeof(DIY));
  *d[28].y = y28;
  d[28].y->item = -1;
  demobrowser7init(d[28].y,pt) ;
  d[29].t = (DIT *)malloc(sizeof(DIO));
  *d[29].o = o29;
  d[29].o->item = -1;
  d[30].t = (DIT *)malloc(sizeof(DIV));
  *d[30].v = v30;
  d[30].v->item = -1;
  d[31].t = (DIT *)malloc(sizeof(DIZ));
  *d[31].z = z31;
  d[31].z->item = -1;
  d[32].t = (DIT *)malloc(sizeof(DIM));
  *d[32].m = m32;
  d[32].m->item = -1;
  d[33].t = NULL;
  GrpId=kgOpenGrp(D);
  D->d = dtmp;
  j=0;
  while(d[j].t!=NULL){ kgAddtoGrp(D,GrpId,(void *)(d[j].t));j++;}
  return GrpId;
} 

/* One can also use the following code to add Widgets to an existing Dialog */

int MakedemoGroup(DIALOG *D,void *arg) {
   int GrpId;
   WIDGETGRP *Gpt;
/*************************************************

    Browser1  1 data value
    Text_Box1  1 data values
    TableBox1  6 data values
    Integerslidebar1  1 data value
    Floatslidebar1  1 data value
    Scrollmenu2  1 data value
    Integerslidebar2  1 data value
    Selectmenu3  1 data value
    RadioButtons4  1 data value
    CheckBox5  1 data value
    ThumbnailBrowser6  1 data value

*************************************************/
   int  *v0 ;
   v0 = (int *)malloc(sizeof(int));
   *v0 = 1;
   int  *v1 ;
   v1 = (int *)malloc(sizeof(int));
   *v1 = 1;
   int  *v2 ;
   v2 = (int *)malloc(sizeof(int));
   *v2 = 1;
   int  *v3 ;
   v3 = (int *)malloc(sizeof(int));
   *v3 = 1;
   int  *v4 ;
   v4 = (int *)malloc(sizeof(int));
   *v4 = 1;
   int  *v5 ;
   v5 = (int *)malloc(sizeof(int));
   *v5 = 1;
   int  *v6 ;
   v6 = (int *)malloc(sizeof(int));
   *v6 = 1;
   int  *v7 ;
   v7 = (int *)malloc(sizeof(int));
   *v7 = 1;
   int  *v8 ;
   v8 = (int *)malloc(sizeof(int));
   *v8 = 1;
   double *v9 ;
   v9 = (double *)malloc(sizeof(double));
   *v9 = 0.0;
   int  *v10 ;
   v10 = (int *)malloc(sizeof(int));
   *v10 = 1;
   int  *v11 ;
   v11 = (int *)malloc(sizeof(int));
   *v11 = 1;
   int  *v12 ;
   v12 = (int *)malloc(sizeof(int));
   *v12 = 1;
   int  *v13 ;
   v13 = (int *)malloc(sizeof(int));
   *v13 = 1;
   int  *v14 ;
   v14 = (int *)malloc(sizeof(int));
   *v14 = 1;
   int  *v15 ;
   v15 = (int *)malloc(sizeof(int));
   *v15 = 1;
   void** v=(void **)malloc(sizeof(void*)*17);
   v[16]=NULL;
   v[0]=(void *)(v0);
   v[1]=(void *)(v1);
   v[2]=(void *)(v2);
   v[3]=(void *)(v3);
   v[4]=(void *)(v4);
   v[5]=(void *)(v5);
   v[6]=(void *)(v6);
   v[7]=(void *)(v7);
   v[8]=(void *)(v8);
   v[9]=(void *)(v9);
   v[10]=(void *)(v10);
   v[11]=(void *)(v11);
   v[12]=(void *)(v12);
   v[13]=(void *)(v13);
   v[14]=(void *)(v14);
   v[15]=(void *)(v15);
   void *pt=NULL; /* pointer to send any extra information */
   GrpId = demoGroup(D,v,pt);
   Gpt = kgGetWidgetGrp(D,GrpId);
   Gpt->arg= v; // kulina will double free this; you may modify
   return GrpId;
}

int demo( void *parent,void **v,void *pt) {
  int ret=1,GrpId,k;
  DIALOG D;
  DIA *d=NULL;
  D.VerId=2107030000;
  kgInitUi(&D);
  D.d=NULL;
#if 1
  GrpId = demoGroup(&D,v,pt);
#else 
  GrpId = MakedemoGroup(&D,pt); // can try this also
#endif 
  d = D.d;
  D.d = d;
  D.bkup = 1; /* set to 1 for backup */
  D.bor_type = 2;
  D.df = 31;
  D.tw = 4;
  D.bw = 43;
  D.lw = 4;
  D.rw = 4;
  D.xo = 446;   /* Position of Dialog */ 
  D.yo = 164;
  D.xl = 1412;    /*  Length of Dialog */
  D.yl = 786;    /*  Width  of Dialog */
  D.Initfun = demoinit;    /*   init fuction for Dialog */
  D.Cleanupfun = democleanup;    /*   init fuction for Dialog */
  D.kbattn = 0;    /*  1 for drawing keyborad attention */
  D.butattn = 0;    /*  1 for drawing button attention */
  D.fullscreen = 0;    /*  1 for for fullscreen mode */
  D.Deco = 1;    /*  1 for Window Decorration */
  D.transparency = 0.000000;    /*  float 1.0 for full transparency */
  D.Newwin = 0;    /*  1 for new window not yet implemented */
  D.DrawBkgr = 1;    /*  1 for drawing background */
  D.Bkpixmap = NULL;    /*  background image */
  D.Sticky = 0;    /*  1 for stickyness */
  D.Resize = 0;    /*  1 for Resize option */
  D.MinWidth = 100;    /*   for Resize option */
  D.MinHeight = 100;    /*   for Resize option */
#if 1 
  D.Callback = demoCallBack;    /*  default callback */
#else 
  D.Callback = NULL;    
#endif
  D.ResizeCallback = demoResizeCallBack;  /*  Resize callback */
#if 0 
  D.WaitCallback = NULL;  /*  Wait callback */
#else 
  D.WaitCallback = demoWaitCallBack;  /*  Wait callback */
#endif
  D.Fixpos = 1;    /*  1 for Fixing Position */
  D.NoTaskBar = 0;    /*  1 for not showing in task bar*/
  D.NoWinMngr = 0;    /*  1 for no Window Manager*/
  D.StackPos = 0;    /* -1,0,1 for for Stack Position -1:below 0:normal 1:above*/
  D.Shapexpm = NULL;    /*  PNG/jpeg file for window shape;Black color will not be drawn */
  D.parent = parent;    /*  1 for not showing in task bar*/
  D.pt = pt;    /*  any data to be passed by user*/
//  strcpy(D.name,"Kulina Designer ver 1.0");    /*  Dialog name you may change */
  if(D.fullscreen!=1) {    /*  if not fullscreen mode */
     int xres,yres; 
     kgDisplaySize(&xres,&yres); 
      // D.xo=D.yo=0; D.xl = xres-10; D.yl=yres-80;
  }
  else {    // for fullscreen
     int xres,yres; 
     kgDisplaySize(&xres,&yres); 
     D.xo=D.yo=0; D.xl = xres; D.yl=yres;
//     D.StackPos = 1; // you may need it
  }    /*  end of fullscreen mode */
  Modifydemo(&D,GrpId);    /*  add extras to  gui*/
  ModifydemoGc(&D);    /*  set colors for gui if don't like default*/
  ret= kgUi(&D);
  kgCleanUi(&D);
  return ret;
}
void *Rundemo(void *arg) {
/*************************************************

    Browser1  1 data value
    Text_Box1  1 data values
    TableBox1  6 data values
    Integerslidebar1  1 data value
    Floatslidebar1  1 data value
    Scrollmenu2  1 data value
    Integerslidebar2  1 data value
    Selectmenu3  1 data value
    RadioButtons4  1 data value
    CheckBox5  1 data value
    ThumbnailBrowser6  1 data value

*************************************************/
   int   v0 = 1;
   int   v1 = 1;
   int   v2 = 1;
   int   v3 = 1;
   int   v4 = 1;
   int   v5 = 1;
   int   v6 = 1;
   int   v7 = 1;
   int   v8 = 1;
   double v9 = 0.0;
   int   v10 = 1;
   int   v11 = 1;
   int   v12 = 1;
   int   v13 = 1;
   int   v14 = 1;
   int   v15 = 1;
   void* v[16];
   v[0]=(void *)(&v0);
   v[1]=(void *)(&v1);
   v[2]=(void *)(&v2);
   v[3]=(void *)(&v3);
   v[4]=(void *)(&v4);
   v[5]=(void *)(&v5);
   v[6]=(void *)(&v6);
   v[7]=(void *)(&v7);
   v[8]=(void *)(&v8);
   v[9]=(void *)(&v9);
   v[10]=(void *)(&v10);
   v[11]=(void *)(&v11);
   v[12]=(void *)(&v12);
   v[13]=(void *)(&v13);
   v[14]=(void *)(&v14);
   v[15]=(void *)(&v15);
   void *pt=NULL; /* pointer to send any extra information */
   demo(NULL,v,pt );
   return NULL;
}
